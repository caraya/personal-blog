var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/google-search.ts
var google_search_exports = {};
__export(google_search_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(google_search_exports);
var handler = async (event, context) => {
  const apiKey = process.env.GOOGLE_API_KEY;
  const cx = process.env.GOOGLE_CX;
  const query = event.queryStringParameters?.q;
  const start = event.queryStringParameters?.start || "1";
  if (!query) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Search query is required." })
    };
  }
  if (!apiKey || !cx) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "API key or CX is not configured on the server." })
    };
  }
  const url = `https://www.googleapis.com/customsearch/v1?key=${apiKey}&cx=${cx}&q=${encodeURIComponent(query)}&start=${start}`;
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Google API responded with status: ${response.status}`);
    }
    const searchData = await response.json();
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(searchData)
    };
  } catch (error) {
    console.error("[google-search function] Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to fetch search results." })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
