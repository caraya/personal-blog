var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var import_dotenv = __toESM(require("dotenv"));
var import_twitter = __toESM(require("twitter"));
var import_html_entities = require("html-entities");
import_dotenv.default.config();
const itemS_URL = "https://publishing-project.rivendellweb.net/feed/feed.json";
const twitter = new import_twitter.default({
  consumer_key: process.env.TWITTER_CONSUMER_KEY,
  consumer_secret: process.env.TWITTER_CONSUMER_SECRET,
  access_token_key: process.env.TWITTER_ACCESS_TOKEN_KEY,
  access_token_secret: process.env.TWITTER_ACCESS_TOKEN_SECRET
});
const handleError = (err) => {
  console.error(err);
  const msg = Array.isArray(err) ? err[0].message : err.message;
  return {
    statusCode: 422,
    body: String(msg)
  };
};
const status = (code, msg) => {
  console.log(msg);
  return {
    statusCode: code,
    body: msg
  };
};
const processitems = async (items) => {
  if (!items.length) {
    return status(404, "No items found to process.");
  }
  const latestitem = items[0];
  if (!latestitem.syndicate) {
    return status(
      400,
      "Latest item has disabled syndication. No action taken."
    );
  }
  try {
    const q = await twitter.get("search/tweets", { q: latestitem.url });
    if (q.statuses && q.statuses.length === 0) {
      return publishitem(latestitem);
    } else {
      return status(
        400,
        "Latest item was already syndicated. No action taken."
      );
    }
  } catch (err) {
    return handleError(err);
  }
};
const prepareStatusText = (item) => {
  const maxLength = 280 - 3 - 1 - 23 - 20;
  let text = item.content.trim().replace(/<[^>]+>/g, "");
  text = (0, import_html_entities.decode)(text);
  if (text.length > maxLength) {
    text = text.substring(0, maxLength) + "...";
  }
  text += " " + item.url;
  if (item.link && item.link.length) {
    text += " " + item.link;
  }
  return text;
};
const publishitem = async (item) => {
  try {
    const statusText = prepareStatusText(item);
    const tweet = await twitter.post("statuses/update", {
      status: statusText
    });
    if (tweet) {
      return status(
        200,
        `item ${item.date} successfully posted to Twitter.`
      );
    } else {
      return status(422, "Error posting to Twitter API.");
    }
  } catch (err) {
    return handleError(err);
  }
};
exports.handler = async () => {
  return fetch(itemS_URL).then((response) => response.json()).then(processitems).catch(handleError);
};
